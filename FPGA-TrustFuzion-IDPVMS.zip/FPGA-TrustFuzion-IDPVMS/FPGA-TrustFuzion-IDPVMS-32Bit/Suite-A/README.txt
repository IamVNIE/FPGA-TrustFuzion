:: ----FPGA TRust Zone Programmer----::
:: NOTE: Make sure FPGA is on and connected. Open a terminal and connect to FPGA with baud rate 9600; 
:: UART Settings: Baud Rate= 9600; Data Bits=8; Stop Bits=1; Parity=None; Handshake =None
:: Start "capture log" before the bit file is programmed
:: 1. Open command prompt from start menu
:: 2. cd to location of the scripts
:: 3. Run "download.cmd" command
:: Wait for 5 minutes till the script says DONE
:: Press "stop capture"
:: Turn off FPGA
:: Send the file to vj338@nyu.edu


 
